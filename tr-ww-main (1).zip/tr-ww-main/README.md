# 🤖 Telegram Bot - نظام متجر إلكتروني متكامل

بوت تيليجرام متطور لإدارة المتاجر الإلكترونية مع دعم Firebase و Flask.

## ✨ المميزات

- 🛒 نظام متجر كامل مع سلة تسوق
- 💰 نظام محفظة ورصيد للمستخدمين
- 🔐 نظام توثيق للمستخدمين
- 👥 لوحة تحكم للمشرفين
- 📦 إدارة المنتجات والطلبات
- 🔥 قاعدة بيانات Firebase
- 🌐 واجهة ويب بـ Flask

## 🚀 البدء السريع

### 1. قراءة الدليل
ابدأ من هنا: **[QUICKSTART.md](QUICKSTART.md)** 📖

### 2. النشر على Render
اتبع الخطوات في: **[DEPLOY.md](DEPLOY.md)** 🚀

### 3. الملفات المُنشأة

```
📁 المشروع/
├── 🐍 app.py                    # الكود الرئيسي
├── 📦 requirements.txt          # المكتبات المطلوبة
├── ⚙️  render.yaml              # تكوين Render
├── 🚀 Procfile                  # أمر التشغيل
├── 🐍 runtime.txt               # إصدار Python
├── ⚙️  gunicorn.conf.py         # إعدادات Gunicorn
├── 📝 .env.example              # مثال متغيرات البيئة
├── 🔧 setup.sh                  # سكريبت الإعداد
├── 📖 QUICKSTART.md             # دليل البدء السريع
├── 📖 DEPLOY.md                 # دليل النشر المفصل
├── 📖 README_RENDER.md          # توثيق Render
├── 📋 تعليمات.txt              # ملخص بالعربية
└── 📋 environment-guide.json    # دليل المتغيرات
```

## 🔑 المتطلبات

### متغيرات البيئة المطلوبة:

1. **BOT_TOKEN** - من [@BotFather](https://t.me/BotFather)
2. **FIREBASE_CREDENTIALS** - من Firebase Console
3. **SITE_URL** - رابط التطبيق على Render
4. **SECRET_KEY** - مفتاح سري للجلسات

التفاصيل في: [environment-guide.json](environment-guide.json)

## 📦 التثبيت المحلي

```bash
# 1. استنساخ المشروع
git clone your-repo-url
cd bothhhhhhhhhhhhh-main

# 2. تثبيت المكتبات
pip install -r requirements.txt

# 3. إعداد البيئة
cp .env.example .env
# عدّل .env وأضف قيمك

# 4. تشغيل
python3 app.py
```

## 🌐 النشر على Render

```bash
# 1. رفع على GitHub
git init
git add .
git commit -m "Initial commit"
git push

# 2. إنشاء Web Service على Render
# - اربط GitHub
# - اختر المستودع
# - أضف متغيرات البيئة
# - انشر!
```

**دليل مفصل:** [DEPLOY.md](DEPLOY.md)

## ⚙️ الإعدادات

### تحديث Admin ID
في [app.py](app.py#L45):
```python
ADMIN_ID = 5665438577  # غيّره لآيدي تيليجرام الخاص بك
```

### إضافة مشرفين
في [app.py](app.py#L50-L55):
```python
ADMINS_LIST = [
    5665438577,  # المشرف الرئيسي
    # أضف المزيد (حتى 10)
]
```

## 📚 التوثيق

| الملف | الوصف |
|-------|--------|
| [QUICKSTART.md](QUICKSTART.md) | ابدأ من هنا - دليل سريع (5 دقائق) |
| [DEPLOY.md](DEPLOY.md) | دليل النشر الكامل على Render |
| [README_RENDER.md](README_RENDER.md) | توثيق تفصيلي لـ Render |
| [environment-guide.json](environment-guide.json) | شرح متغيرات البيئة |
| [تعليمات.txt](تعليمات.txt) | ملخص سريع بالعربية |

## 🛠️ التقنيات المستخدمة

- 🐍 **Python 3.11**
- 🤖 **pyTelegramBotAPI** - للتفاعل مع Telegram
- 🌐 **Flask** - إطار عمل الويب
- 🔥 **Firebase Admin SDK** - قاعدة البيانات
- 🚀 **Gunicorn** - خادم WSGI للإنتاج

## 🆘 حل المشاكل

### البوت لا يستجيب؟
- تحقق من Logs في Render Dashboard
- تأكد من صحة `BOT_TOKEN`
- تحقق من حالة السيرفر (Live)

### خطأ Firebase؟
- تأكد من صحة `FIREBASE_CREDENTIALS`
- احذف المسافات والأسطر الجديدة
- تحقق من صلاحيات Service Account

### فشل البناء؟
- راجع `requirements.txt`
- تحقق من `runtime.txt`
- راجع Logs للتفاصيل

**المزيد:** [DEPLOY.md#استكشاف-الأخطاء](DEPLOY.md)

## 📄 الترخيص

هذا المشروع مفتوح المصدر.

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:
1. عمل Fork للمشروع
2. إنشاء Branch للميزة الجديدة
3. Commit للتغييرات
4. Push للـ Branch
5. فتح Pull Request

## 📞 الدعم

- 📖 اقرأ [QUICKSTART.md](QUICKSTART.md) للبدء
- 📖 اقرأ [DEPLOY.md](DEPLOY.md) للتفاصيل
- 🔍 تحقق من [environment-guide.json](environment-guide.json) للمتغيرات

---

<div align="center">

**🎉 مشروعك جاهز للنشر! 🎉**

[ابدأ الآن →](QUICKSTART.md)

</div>
